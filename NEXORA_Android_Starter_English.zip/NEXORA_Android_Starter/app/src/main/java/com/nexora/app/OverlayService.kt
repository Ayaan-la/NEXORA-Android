package com.nexora.app
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
class OverlayService: Service() {
 private var icon: TextView?=null
 private lateinit var wm: WindowManager
 override fun onCreate(){ super.onCreate(); if(!Settings.canDrawOverlays(this)){stopSelf();return}
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val bubble=TextView(this).apply { text="✦"; textSize=27f; gravity=Gravity.CENTER; setTextColor(0xFF65E7FF.toInt()); setBackgroundColor(0xDD101A2B.toInt()); contentDescription="NEXORA floating icon" }
  val p=WindowManager.LayoutParams(58,58,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=16; y=220 }
  var sx=0f; var sy=0f; var px=0; var py=0
  bubble.setOnTouchListener { _,e -> when(e.action){
   MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;px=p.x;py=p.y;true}
   MotionEvent.ACTION_MOVE->{p.x=px+(sx-e.rawX).toInt();p.y=py+(e.rawY-sy).toInt();wm.updateViewLayout(bubble,p);true}
   MotionEvent.ACTION_UP->{if(kotlin.math.abs(e.rawX-sx)+kotlin.math.abs(e.rawY-sy)<12){packageManager.getLaunchIntentForPackage(packageName)?.let{it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(it)}};true}
   else->false } }
  icon=bubble; wm.addView(bubble,p)
 }
 override fun onDestroy(){icon?.let{wm.removeView(it)};icon=null;super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
