package com.nexora.app
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16) }
  val web=WebView(this).apply { settings.javaScriptEnabled=true; webViewClient=WebViewClient(); loadUrl("file:///android_asset/index.html") }
  val button=Button(this).apply { text="Enable floating icon"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
   else startService(Intent(this@MainActivity,OverlayService::class.java))
  } }
  layout.addView(button); layout.addView(web,LinearLayout.LayoutParams(-1,0,1f)); setContentView(layout)
 }
 override fun onResume(){ super.onResume(); if(Settings.canDrawOverlays(this)) startService(Intent(this,OverlayService::class.java)) }
}
