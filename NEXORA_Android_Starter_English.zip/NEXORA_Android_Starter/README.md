# NEXORA Android Starter

## Priority
1. Main UI: `app/src/main/assets/index.html` (edit/design this first).
2. Floating icon: `app/src/main/java/com/nexora/app/OverlayService.kt`.
3. The icon is intended to float above other apps after Android's Display over other apps permission is granted.

## Prototype limitations
This is an untested starter project. The chart is decorative; there is no live market feed, real signal engine, or auto-trading. Do not use it for real-money decisions.

## Build
Push the project to GitHub. The included Actions workflow builds a debug APK.
